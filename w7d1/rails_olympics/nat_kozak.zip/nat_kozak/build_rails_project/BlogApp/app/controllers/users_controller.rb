class UsersController < ApplicationController
  def create
  end

  def new
  end

  def show
  end

end
