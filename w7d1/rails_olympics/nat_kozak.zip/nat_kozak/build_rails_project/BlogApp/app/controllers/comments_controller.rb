class CommentsController < ApplicationController

  def create
  end

  def destroy
  end
end
